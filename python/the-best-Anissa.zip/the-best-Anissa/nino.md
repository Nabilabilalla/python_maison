# NINO

![contratApprentissage](/home/muriel/Documents/CDA/images/contratApprentissage.gif)

## Passions

* lecture
* voyages 🏝 
* découverte ⛩ 

## Attentes de la formation

* avoir plus de confiance en soi
* faire ce que j'aime
* trouver un emploi

## Craintes de la formation

* de ne pas trouver une entreprise pour le CDA
* de ne pas finir la formation 

## Objectifs de la formation

* trouver une entreprise pour un contrat d'alternance
* avoir sa certification de développeur web
* progresser dans mes compétences



