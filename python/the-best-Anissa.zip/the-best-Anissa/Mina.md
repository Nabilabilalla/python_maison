# Mina

Habite à Marseille, elle aime les voyages, la lecture, l'écriture.Elle aime aussi le cinéma avec une préférence pour la SF, le fantastique et les séries américaines, coréennes, japonnaises....

![](/home/amour/Téléchargements/monfuji.jpg)

Son attente concernant la formation est de trouver un emploi dans le développement web plutôt au sein d'une entreprise qu'en freelance dans un premier temps. 

Sa crainte est d'avoir du mal à trouver une alternance et donc de ne pas pouvoir aller au bout de sa formation.  

