## Présentation de la vie de mon collégue Lucas de Cannes ! :star:

`une petite interview de Lucas sur sa vie en générale` :

1. Lucas à 26 ans !:sunglasses:
2. Il voudrait travailler dans le front pour le moment puis plutard passer sur du back
3. Il a fait son stage chez Manageo et peut-etre une réponse positif pour une alternance ( je croise les doigts) 

``je sais que mon collègue Lucas va reussir ses objectifs clap clap`` 

4. Lucas aime aussi beaucoup les animations japonaise ! :trollface:
5. Lucas aime beaucoup monter des pc 
6. il galere à trouver les bon matériaux car le prix est méga chere 
7. Lucas fait de la chasse sous marine ( mon dieu incroyable je suis jalouse j'ai juste vu des gros poissons a marineland leul)
8. ET en plus MUSICIEN ????? il joue de la guitar (le talent) [https://giphy.com/gifs/9Dgf4pFMzSrTrE4Urj/html5](https://giphy.com/gifs/9Dgf4pFMzSrTrE4Urj/html5)
9. Il a peur de pas trouver de taff à la fin de la formation ou meme une alternance pour le CDA.

``il va trouver j'en suis sur``

10. Il travailler dans le batiment son entreprise à coulé donc il a du trouver en autre travaille chez la poste (respect car dure période tu mérite d'etre riche et te reposer à dubai)
11. il veux travailler dans une ESN, dans un poste qui paie bien !
12. Lucas aime en générale le numérique depuis sont plus jeune age.il pensais que c'était reservé pour les gens fort en maths ( Bac S leul leul) il sait jamais amusé dans un taff et un jour après un déclic il lache son taff pour commencer sa reconversion chez Simplon.

``je te souhaite de reussir``