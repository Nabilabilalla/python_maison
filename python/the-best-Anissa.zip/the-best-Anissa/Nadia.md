#  ![](http://mademoisellesophia.m.a.pic.centerblog.net/vdq01mu4.gif)

# `Formation Developpeus web`

- *HTML*

- *CSS*

- *JAVASCRIPT*

- *PHP* 

- LARAVEL ReactJS ++ 

- *SQL*

- *BD* 

- *WORDPRESS* 

- *BOOTSTRAP* 

 # <img src="https://4h1j93agxrz3lx3iv46cbhfk-wpengine.netdna-ssl.com/wp-content/uploads/2017/12/AIME-Logo.png" style="zoom:25%;" />

- *Design*

- *Création Art*

  ### Stage 

- *C2S Bouygues ReactJS + Materail UI* 

 ### Présentation

- *Prezi.com*

 ## Les attentes  

- *Gestion de projet, savoir tout les étapes* 

- *pouvoir d'être autonome et savoir travailler en équipe*
-  *L'obtention de la certification*
-  *Le partage des connaissance. Contrat Pro*

![](/home/nabila/Téléchargements/psd.png)